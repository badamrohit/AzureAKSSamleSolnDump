﻿using System;

namespace mydotnetapp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("waiting for 2 min before exiting");
          //  System.Threading.Thread.sleep(120000);
            Console.WriteLine("Exiting now");
             Console.WriteLine("Exiting now");
        }
    }
}
