"localhost","127.0.0.1" | foreach-object {$processortype = Get-WmiObject -class Win32_Processor -ComputerName $_ |Select-Object  AddressWidth 

    Write-Host "Processor Architecture `t " -NoNewline -ForegroundColor Yellow 

    Write-Host  "$_ `t " -NoNewline -ForegroundColor Yellow 

    Write-Host $processortype.AddressWidth  -ForegroundColor Green

    }
    [System.Threading.Thread]::Sleep(180000)
    Get-ChildItem c:\windows\system32 -Recurse -Filter *.dll -ErrorAction SilentlyContinue